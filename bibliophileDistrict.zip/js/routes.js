angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('login', {
    url: '/page5',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('signup', {
    url: '/page6',
    templateUrl: 'templates/signup.html',
    controller: 'signupCtrl'
  })

  .state('category', {
    url: '/page7',
    templateUrl: 'templates/category.html',
    controller: 'categoryCtrl'
  })

  .state('bookTitlePage', {
    url: '/page8',
    templateUrl: 'templates/bookTitlePage.html',
    controller: 'bookTitlePageCtrl'
  })

  .state('authorPage', {
    url: '/page13',
    templateUrl: 'templates/authorPage.html',
    controller: 'authorPageCtrl'
  })

  .state('genrePage', {
    url: '/page14',
    templateUrl: 'templates/genrePage.html',
    controller: 'genrePageCtrl'
  })

  .state('aboutBook', {
    url: '/page11',
    templateUrl: 'templates/aboutBook.html',
    controller: 'aboutBookCtrl'
  })

  .state('page', {
    url: '/page12',
    templateUrl: 'templates/page.html',
    controller: 'pageCtrl'
  })

$urlRouterProvider.otherwise('')

  

});