angular.module('app.controllers', [])
        
.controller('loginCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('categoryCtrl', function($scope) {

})
   
.controller('bookTitlePageCtrl', function($scope) {

})
   
.controller('authorPageCtrl', function($scope) {

})
   
.controller('genrePageCtrl', function($scope) {

})
   
.controller('aboutBookCtrl', function($scope) {

})
   
.controller('pageCtrl', function($scope) {

})
 